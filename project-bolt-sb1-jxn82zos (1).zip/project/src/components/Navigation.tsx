import { useEffect, useState } from 'react';
import { Menu, X } from 'lucide-react';

const LINKS = [
  { label: 'HOME', href: '#home' },
  { label: 'ABOUT', href: '#about' },
  { label: 'SKILLS', href: '#skills' },
  { label: 'PROJECTS', href: '#projects' },
  { label: 'EDUCATION', href: '#education' },
  { label: 'INSPIRATION', href: '#inspiration' },
  { label: 'GRATITUDE', href: '#gratitude' },
  { label: 'CONTACT', href: '#contact' },
];

export default function Navigation() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState('#home');

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 24);
      const sections = LINKS.map((l) => l.href.slice(1));
      let current = '#home';
      for (const id of sections) {
        const el = document.getElementById(id);
        if (el && el.getBoundingClientRect().top <= 120) current = `#${id}`;
      }
      setActive(current);
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : '';
    return () => {
      document.body.style.overflow = '';
    };
  }, [open]);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
        scrolled
          ? 'border-b border-reactor-line/60 bg-reactor-bg/85 backdrop-blur-md'
          : 'border-b border-transparent bg-transparent'
      }`}
    >
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-5 py-3.5 sm:px-8">
        <a href="#home" className="group flex items-center gap-2.5">
          <span className="relative flex h-7 w-7 items-center justify-center">
            <span className="absolute inset-0 rounded-full border border-reactor-cyan/60" />
            <span className="absolute inset-1.5 rounded-full border border-reactor-cyan/40 animate-spin-slow" />
            <span className="h-2 w-2 rounded-full bg-reactor-cyan shadow-[0_0_10px_2px_rgba(34,211,238,0.8)] animate-pulse-core" />
          </span>
          <span className="font-display text-sm font-bold tracking-[0.25em] text-white">
            SURJITH
          </span>
        </a>

        <ul className="hidden items-center gap-1 lg:flex">
          {LINKS.map((l) => (
            <li key={l.href}>
              <a
                href={l.href}
                className={`relative px-3 py-2 font-mono text-[11px] uppercase tracking-[0.2em] transition-colors ${
                  active === l.href ? 'text-reactor-glow' : 'text-reactor-text/60 hover:text-reactor-glow'
                }`}
              >
                {l.label}
                {active === l.href && (
                  <span className="absolute inset-x-2 -bottom-0.5 h-px bg-reactor-cyan shadow-[0_0_8px_rgba(34,211,238,0.8)]" />
                )}
              </a>
            </li>
          ))}
        </ul>

        <button
          onClick={() => setOpen((o) => !o)}
          className="flex h-9 w-9 items-center justify-center rounded-md border border-reactor-line/70 text-reactor-cyan lg:hidden"
          aria-label="Toggle navigation"
          aria-expanded={open}
        >
          {open ? <X size={18} /> : <Menu size={18} />}
        </button>
      </nav>

      {/* Mobile drawer */}
      <div
        className={`overflow-hidden border-t border-reactor-line/40 bg-reactor-bg/95 backdrop-blur-md transition-[max-height,opacity] duration-500 lg:hidden ${
          open ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
        }`}
      >
        <ul className="flex flex-col gap-1 px-5 py-4">
          {LINKS.map((l, i) => (
            <li
              key={l.href}
              style={{ transitionDelay: open ? `${i * 40}ms` : '0ms' }}
              className={`transition-all duration-500 ${
                open ? 'translate-x-0 opacity-100' : '-translate-x-4 opacity-0'
              }`}
            >
              <a
                href={l.href}
                onClick={() => setOpen(false)}
                className={`block rounded-md px-4 py-3 font-mono text-xs uppercase tracking-[0.25em] transition-colors ${
                  active === l.href
                    ? 'border-l-2 border-reactor-cyan bg-reactor-cyan/10 text-reactor-glow'
                    : 'border-l-2 border-transparent text-reactor-text/70 hover:bg-reactor-cyan/5 hover:text-reactor-glow'
                }`}
              >
                {l.label}
              </a>
            </li>
          ))}
        </ul>
      </div>
    </header>
  );
}

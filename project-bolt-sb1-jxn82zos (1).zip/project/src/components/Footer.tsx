import { ArrowUp } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="relative border-t border-reactor-line/50 bg-reactor-bg/80">
      <div className="absolute inset-0 grid-bg opacity-20" />
      <div className="relative mx-auto max-w-7xl px-5 py-10 sm:px-8">
        <div className="flex flex-col items-center justify-between gap-6 sm:flex-row">
          <div className="flex items-center gap-2.5">
            <span className="relative flex h-6 w-6 items-center justify-center">
              <span className="absolute inset-0 rounded-full border border-reactor-cyan/60" />
              <span className="h-1.5 w-1.5 rounded-full bg-reactor-cyan shadow-[0_0_8px_2px_rgba(34,211,238,0.8)]" />
            </span>
            <span className="font-display text-sm font-bold tracking-[0.25em] text-white">
              SURJITH
            </span>
          </div>

          <p className="text-center font-mono text-[10px] uppercase tracking-[0.25em] text-reactor-text/40">
            STUDENT · PROGRAMMER · ROBOTICS ENTHUSIAST
          </p>

          <a
            href="#home"
            className="group flex items-center gap-2 rounded-md border border-reactor-line/60 px-4 py-2 font-mono text-[10px] uppercase tracking-[0.2em] text-reactor-text/60 transition-all hover:border-reactor-cyan/50 hover:text-reactor-glow"
          >
            BACK TO TOP
            <ArrowUp size={13} className="transition-transform group-hover:-translate-y-0.5" />
          </a>
        </div>

        <div className="mt-8 border-t border-reactor-line/40 pt-6 text-center">
          <p className="text-xs text-reactor-text/40">
            Built with React &amp; Tailwind CSS · Arc Reactor interface designed as original artwork.
          </p>
          <p className="mt-1 font-mono text-[10px] uppercase tracking-[0.2em] text-reactor-text/30">
            © {new Date().getFullYear()} SURJITH · ALL SYSTEMS OPERATIONAL
          </p>
        </div>
      </div>
    </footer>
  );
}

import { Cpu, CircuitBoard, Wrench, BookOpen, Heart } from 'lucide-react';

const FACTS = [
  { icon: BookOpen, label: 'SCHOOL', value: 'Sri Sankara Vidyalayaa, Karur' },
  { icon: Cpu, label: 'BOARD', value: 'CBSE' },
  { icon: Wrench, label: 'FOCUS', value: 'Programming · Robotics · Automation · Electronics · Engineering' },
];

export default function About() {
  return (
    <section id="about" className="relative py-24 sm:py-32">
      <div className="absolute inset-0 grid-bg opacity-30" />
      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <div className="reveal mb-14 text-center">
          <p className="section-eyebrow">// 01 — PROFILE</p>
          <h2 className="section-title mt-3">ABOUT ME</h2>
          <div className="mx-auto mt-4 h-px w-24 bg-gradient-to-r from-transparent via-reactor-cyan to-transparent" />
        </div>

        <div className="grid gap-8 lg:grid-cols-[1.1fr_0.9fr]">
          {/* Narrative */}
          <div className="reveal hud-panel p-7 sm:p-9">
            <span className="hud-corner left-2 top-2 border-l border-t" />
            <span className="hud-corner right-2 top-2 border-r border-t" />
            <span className="hud-corner left-2 bottom-2 border-l border-b" />
            <span className="hud-corner right-2 bottom-2 border-r border-b" />

            <h3 className="font-display text-2xl font-bold text-white">
              A student building real things with code &amp; circuits.
            </h3>
            <p className="mt-5 text-base leading-relaxed text-reactor-text/75">
              I&apos;m a student curious about how things work — from a single line of C code to a
              microcontroller blinking its first LED. I spend my time learning programming,
              experimenting with electronics, and building robotics and automation projects that
              solve real problems around me.
            </p>
            <p className="mt-4 text-base leading-relaxed text-reactor-text/75">
              I believe the best way to learn engineering is by building — testing ideas, failing,
              debugging, and improving. Every project here is part of that journey.
            </p>

            <div className="mt-7 space-y-3">
              {FACTS.map((f) => (
                <div key={f.label} className="flex items-start gap-3 rounded-lg border border-reactor-line/40 bg-reactor-surface/40 px-4 py-3">
                  <f.icon size={18} className="mt-0.5 shrink-0 text-reactor-cyan" />
                  <div>
                    <div className="font-mono text-[10px] uppercase tracking-[0.25em] text-reactor-text/50">
                      {f.label}
                    </div>
                    <div className="text-sm font-medium text-reactor-text">{f.value}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Visual: abstract scientist/space panel */}
          <div className="reveal relative overflow-hidden rounded-xl border border-reactor-line/60 bg-reactor-panel/50">
            <div className="absolute inset-0">
              <div
                className="absolute inset-0"
                style={{
                  background:
                    'radial-gradient(circle at 50% 35%, rgba(34,211,238,0.18), transparent 55%), radial-gradient(circle at 80% 80%, rgba(59,130,246,0.14), transparent 50%)',
                }}
              />
              {/* Constellation dots */}
              <svg viewBox="0 0 400 400" className="h-full w-full opacity-70">
                {Array.from({ length: 40 }).map((_, i) => (
                  <circle
                    key={i}
                    cx={(i * 97) % 400}
                    cy={(i * 61) % 400}
                    r={i % 4 === 0 ? 1.6 : 0.8}
                    fill={i % 5 === 0 ? '#67e8f9' : '#3b82f6'}
                    opacity={0.5 + (i % 3) * 0.15}
                  />
                ))}
                <g stroke="rgba(34,211,238,0.25)" strokeWidth="1" fill="none">
                  <path d="M60 120 L150 80 L240 140 L320 90" />
                  <path d="M80 260 L180 220 L260 300 L340 250" />
                  <path d="M120 60 L120 180 L220 220" />
                </g>
                {/* Orbit */}
                <g className="origin-center animate-spin-slower" style={{ transformOrigin: '200px 200px' }}>
                  <ellipse cx="200" cy="200" rx="150" ry="60" fill="none" stroke="rgba(34,211,238,0.3)" />
                  <circle cx="350" cy="200" r="4" fill="#22d3ee" />
                </g>
                <g className="origin-center animate-spin-reverse-slow" style={{ transformOrigin: '200px 200px' }}>
                  <ellipse cx="200" cy="200" rx="110" ry="44" fill="none" stroke="rgba(59,130,246,0.25)" />
                  <circle cx="90" cy="200" r="3" fill="#3b82f6" />
                </g>
                <circle cx="200" cy="200" r="14" fill="#67e8f9" opacity="0.9" />
                <circle cx="200" cy="200" r="6" fill="#ffffff" />
              </svg>
            </div>
            <div className="relative flex h-full min-h-[260px] flex-col justify-end p-6">
              <div className="flex items-center gap-2 text-reactor-cyan/80">
                <CircuitBoard size={16} />
                <span className="font-mono text-[10px] uppercase tracking-[0.3em]">
                  ENGINEERING MINDSET
                </span>
              </div>
              <p className="mt-2 font-display text-lg font-semibold text-white">
                Curiosity. Circuits. Code.
              </p>
            </div>
          </div>
        </div>

        {/* Kalam mini-callout */}
        <div className="reveal mt-10 flex items-center gap-4 rounded-xl border border-reactor-amber/30 bg-reactor-amber/5 px-6 py-5">
          <Heart size={20} className="shrink-0 text-reactor-amber" />
          <p className="text-sm leading-relaxed text-reactor-text/80">
            <span className="font-semibold text-reactor-amber">Inspiration:</span>{' '}
            Dr. A. P. J. Abdul Kalam — his vision, scientific thinking, dedication and humility
            drive me to learn, dream bigger, and use technology to contribute to society.
          </p>
        </div>
      </div>
    </section>
  );
}

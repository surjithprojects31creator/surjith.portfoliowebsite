import { Languages as LangIcon, Bike, Dumbbell } from 'lucide-react';

const LANGS = [
  { name: 'Tamil', role: 'Mother Tongue', level: 95, color: 'text-reactor-cyan', stroke: '#22d3ee' },
  { name: 'English', role: 'Communication & Technical Language', level: 75, color: 'text-reactor-blue', stroke: '#3b82f6' },
  { name: 'Japanese', role: 'Learning / Communication', level: 25, color: 'text-reactor-amber', stroke: '#f59e0b' },
];

function Ring({ level, color, label, role }: { level: number; color: string; label: string; role: string }) {
  const r = 52;
  const circ = 2 * Math.PI * r;
  return (
    <div className="flex flex-col items-center">
      <div className="relative h-32 w-32">
        <svg viewBox="0 0 120 120" className="h-full w-full -rotate-90">
          <circle cx="60" cy="60" r={r} fill="none" stroke="rgba(30,58,82,0.5)" strokeWidth="4" />
          <circle
            cx="60"
            cy="60"
            r={r}
            fill="none"
            stroke={color}
            strokeWidth="4"
            strokeLinecap="round"
            strokeDasharray={circ}
            strokeDashoffset={circ - (level / 100) * circ}
            style={{ filter: `drop-shadow(0 0 6px ${color})` }}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className={`font-display text-2xl font-bold ${color}`}>{level}%</span>
          <span className="font-mono text-[8px] uppercase tracking-[0.2em] text-reactor-text/50">
            FLUX
          </span>
        </div>
        {/* tick marks */}
        {Array.from({ length: 24 }).map((_, i) => {
          const a = (i / 24) * Math.PI * 2;
          return (
            <span
              key={i}
              className="absolute h-1 w-px bg-reactor-line/70"
              style={{
                left: `${50 + Math.cos(a) * 47}%`,
                top: `${50 + Math.sin(a) * 47}%`,
                transform: `rotate(${(i / 24) * 360}deg)`,
              }}
            />
          );
        })}
      </div>
      <h4 className="mt-4 font-display text-base font-bold text-white">{label}</h4>
      <p className="mt-1 text-center text-xs text-reactor-text/60">{role}</p>
    </div>
  );
}

const HOBBIES = [
  { icon: Dumbbell, name: 'Badminton', desc: 'Quick reflexes, focus and competitive spirit.', accent: 'text-reactor-cyan', border: 'border-reactor-cyan/40' },
  { icon: Bike, name: 'Cycling', desc: 'Long rides, fresh air and an active lifestyle.', accent: 'text-reactor-blue', border: 'border-reactor-blue/40' },
];

export default function Languages() {
  return (
    <section className="relative py-24 sm:py-32">
      <div className="absolute inset-0 grid-bg opacity-30" />
      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        {/* Languages */}
        <div className="reveal mb-20">
          <div className="mb-12 text-center">
            <p className="section-eyebrow">// 06 — COMMUNICATION</p>
            <h2 className="section-title mt-3">LANGUAGES</h2>
            <div className="mx-auto mt-4 h-px w-24 bg-gradient-to-r from-transparent via-reactor-cyan to-transparent" />
          </div>
          <div className="grid gap-10 sm:grid-cols-3">
            {LANGS.map((l) => (
              <Ring key={l.name} level={l.level} color={l.stroke} label={l.name} role={l.role} />
            ))}
          </div>
          <p className="mx-auto mt-8 max-w-xl text-center text-xs text-reactor-text/50">
            <LangIcon size={13} className="mb-0.5 mr-1 inline text-reactor-cyan/70" />
            Proficiency shown as an approximate indicator only — not a certified measurement.
          </p>
        </div>

        {/* Hobbies */}
        <div className="reveal">
          <div className="mb-12 text-center">
            <p className="section-eyebrow">// 07 — OFFLINE MODULES</p>
            <h2 className="section-title mt-3">HOBBIES</h2>
            <div className="mx-auto mt-4 h-px w-24 bg-gradient-to-r from-transparent via-reactor-cyan to-transparent" />
            <p className="mx-auto mt-4 max-w-xl text-sm text-reactor-text/60">
              Not only circuits and code — an active life outside the lab too.
            </p>
          </div>
          <div className="mx-auto grid max-w-2xl gap-5 sm:grid-cols-2">
            {HOBBIES.map((h, i) => (
              <div
                key={h.name}
                style={{ animationDelay: `${i * 80}ms` }}
                className={`group relative overflow-hidden rounded-xl border ${h.border} bg-reactor-panel/40 p-7 transition-all duration-300 hover:-translate-y-1.5 hover:bg-reactor-panel/70`}
              >
                <div className="absolute -right-6 -top-6 h-24 w-24 rounded-full bg-reactor-cyan/5 blur-2xl transition-all group-hover:bg-reactor-cyan/10" />
                <div className={`relative flex h-14 w-14 items-center justify-center rounded-full border ${h.border} bg-reactor-surface/60 ${h.accent} transition-transform group-hover:scale-110`}>
                  <h.icon size={26} />
                </div>
                <h3 className="relative mt-5 font-display text-lg font-bold text-white">{h.name}</h3>
                <p className="relative mt-1.5 text-sm text-reactor-text/65">{h.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

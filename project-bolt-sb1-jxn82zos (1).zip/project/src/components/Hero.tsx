import { useEffect, useState } from 'react';
import Reactor from './Reactor';
import { ArrowRight, User } from 'lucide-react';

const STATS = [
  { label: 'PROJECTS', value: '06' },
  { label: 'DOMAINS', value: '04' },
  { label: 'STATUS', value: 'ONLINE' },
];

export default function Hero() {
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => setMounted(true), 80);
    return () => clearTimeout(t);
  }, []);

  return (
    <section id="home" className="relative min-h-screen overflow-hidden pt-24">
      {/* Background grid + vignette */}
      <div className="absolute inset-0 grid-bg opacity-60" />
      <div className="absolute inset-0 radial-vignette" />
      <div
        className="absolute inset-0"
        style={{ background: 'radial-gradient(ellipse at 80% 50%, rgba(34,211,238,0.08), transparent 50%)' }}
      />

      {/* Floating particles */}
      {Array.from({ length: 18 }).map((_, i) => (
        <span
          key={i}
          className="absolute rounded-full bg-reactor-cyan/40 animate-float"
          style={{
            left: `${(i * 53) % 100}%`,
            top: `${(i * 37) % 100}%`,
            width: `${1 + (i % 3)}px`,
            height: `${1 + (i % 3)}px`,
            animationDelay: `${i * 0.6}s`,
            animationDuration: `${8 + (i % 6)}s`,
          }}
        />
      ))}

      <div className="relative mx-auto grid max-w-7xl items-center gap-10 px-5 pb-16 sm:px-8 lg:grid-cols-[1.05fr_0.95fr] lg:gap-6 lg:pb-24">
        {/* Left: text */}
        <div className={`order-2 lg:order-1 ${mounted ? 'animate-rise' : 'opacity-0'}`}>
          <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-reactor-line/70 bg-reactor-panel/40 px-3 py-1.5">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-reactor-green shadow-[0_0_8px_2px_rgba(16,185,129,0.7)]" />
            <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-reactor-cyan/80">
              SYSTEM ONLINE
            </span>
          </div>

          <h1 className="font-display text-5xl font-extrabold tracking-tight text-white sm:text-6xl md:text-7xl">
            <span className="glow-text">SURJITH</span>
          </h1>

          <p className="mt-3 font-mono text-xs uppercase tracking-[0.3em] text-reactor-cyan/80 sm:text-sm">
            Student &nbsp;•&nbsp; Programmer &nbsp;•&nbsp; Robotics &amp; Automation Enthusiast
          </p>

          <h2 className="mt-7 max-w-xl font-display text-2xl font-bold leading-tight text-white sm:text-3xl md:text-4xl">
            BUILDING THE FUTURE,
            <br />
            ONE IDEA AT A TIME.
          </h2>

          <p className="mt-5 max-w-xl text-base leading-relaxed text-reactor-text/70 sm:text-lg">
            Exploring the world of programming, robotics, automation, electronics and engineering
            through real-world projects and continuous learning.
          </p>

          <div className="mt-8 flex flex-wrap gap-4">
            <a href="#projects" className="btn-primary group">
              EXPLORE PROJECTS
              <ArrowRight size={15} className="transition-transform group-hover:translate-x-1" />
            </a>
            <a href="#about" className="btn-ghost group">
              <User size={15} />
              ABOUT ME
            </a>
          </div>

          {/* Stat strip */}
          <div className="mt-10 grid max-w-md grid-cols-3 gap-3">
            {STATS.map((s) => (
              <div key={s.label} className="hud-panel px-4 py-3">
                <div className="font-display text-xl font-bold text-reactor-glow">{s.value}</div>
                <div className="mt-0.5 font-mono text-[9px] uppercase tracking-[0.25em] text-reactor-text/50">
                  {s.label}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right: reactor */}
        <div className={`order-1 flex justify-center lg:order-2 lg:justify-end ${mounted ? 'animate-rise' : 'opacity-0'}`}>
          <div className="relative">
            <Reactor size={typeof window !== 'undefined' && window.innerWidth < 640 ? 320 : 480} />
          </div>
        </div>
      </div>

      {/* Scroll cue */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2">
        <span className="font-mono text-[9px] uppercase tracking-[0.4em] text-reactor-text/40">
          SCROLL
        </span>
        <span className="relative h-10 w-px overflow-hidden bg-reactor-line/60">
          <span className="absolute inset-x-0 top-0 h-3 animate-scan bg-reactor-cyan" />
        </span>
      </div>
    </section>
  );
}

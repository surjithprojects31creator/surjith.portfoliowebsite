import { Compass, HeartHandshake, GraduationCap, Quote } from 'lucide-react';

const ACKNOWLEDGEMENTS = [
  {
    icon: Compass,
    role: 'MY MENTORS',
    title: 'Guidance & Belief',
    text: 'I would like to express my deepest and heartfelt gratitude to my respected mentors — Madhavan Sir, Rajasekaran Sir, Karthikeyan Sir, Maheshwaran Sir, and Vasanthan Sir — whose constant guidance, encouragement, and belief in me have helped me reach this level of confidence and develop my skills.',
    names: ['Madhavan Sir', 'Rajasekaran Sir', 'Karthikeyan Sir', 'Maheshwaran Sir', 'Vasanthan Sir'],
    accent: 'text-reactor-cyan',
    border: 'border-reactor-cyan/40',
    glow: 'rgba(34,211,238,0.12)',
  },
  {
    icon: HeartHandshake,
    role: 'MY PARENTS',
    title: 'Unwavering Support',
    text: 'I am sincerely thankful to my beloved parents for giving me the opportunity to study at Sri Sankara Vidyalayaa, Karur, and for always supporting and encouraging me in my education, projects, and ambitions.',
    names: [],
    accent: 'text-reactor-blue',
    border: 'border-reactor-blue/40',
    glow: 'rgba(59,130,246,0.12)',
  },
  {
    icon: GraduationCap,
    role: 'SCHOOL CORRESPONDENT SIR',
    title: 'Inspiration to Create',
    text: 'I would like to extend my respectful thanks to our School Correspondent Sir for his valuable encouragement and motivation towards innovative projects and for inspiring us to explore, learn, and create new things.',
    names: [],
    accent: 'text-reactor-amber',
    border: 'border-reactor-amber/40',
    glow: 'rgba(245,158,11,0.12)',
  },
];

export default function Gratitude() {
  return (
    <section id="gratitude" className="relative overflow-hidden py-24 sm:py-32">
      <div className="absolute inset-0 grid-bg opacity-30" />
      <div
        className="absolute inset-0"
        style={{
          background:
            'radial-gradient(ellipse at 30% 20%, rgba(34,211,238,0.08), transparent 50%), radial-gradient(ellipse at 70% 80%, rgba(245,158,11,0.06), transparent 50%)',
        }}
      />
      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <div className="reveal mb-14 text-center">
          <p className="section-eyebrow">// 09 — GRATITUDE</p>
          <h2 className="section-title mt-3">GRATITUDE &amp; ACKNOWLEDGEMENTS</h2>
          <div className="mx-auto mt-4 h-px w-24 bg-gradient-to-r from-transparent via-reactor-cyan to-transparent" />
          <h3 className="mx-auto mt-6 max-w-2xl font-display text-xl font-semibold text-reactor-text/80 sm:text-2xl">
            The People Behind My Journey
          </h3>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          {ACKNOWLEDGEMENTS.map((a, i) => (
            <div
              key={a.role}
              style={{ animationDelay: `${i * 80}ms` }}
              className="reveal group relative overflow-hidden rounded-xl border border-reactor-line/60 bg-reactor-panel/40 p-7 transition-all duration-300 hover:-translate-y-1.5 hover:bg-reactor-panel/70"
            >
              <span className="hud-corner left-2 top-2 border-l border-t" />
              <span className="hud-corner right-2 top-2 border-r border-t" />
              <span className="hud-corner left-2 bottom-2 border-l border-b" />
              <span className="hud-corner right-2 bottom-2 border-r border-b" />

              <div
                className="absolute -right-8 -top-8 h-28 w-28 rounded-full blur-2xl transition-all duration-500 group-hover:opacity-100"
                style={{ background: a.glow, opacity: 0.5 }}
              />

              <div className="relative">
                <div
                  className={`flex h-14 w-14 items-center justify-center rounded-full border ${a.border} bg-reactor-surface/60 ${a.accent} transition-transform duration-300 group-hover:scale-110`}
                >
                  <a.icon size={26} />
                </div>

                <p className="mt-5 font-mono text-[10px] uppercase tracking-[0.25em] text-reactor-text/50">
                  {a.role}
                </p>
                <h3 className="mt-1.5 font-display text-lg font-bold text-white">
                  {a.title}
                </h3>
                <p className="mt-4 text-sm leading-relaxed text-reactor-text/70">
                  {a.text}
                </p>
                {a.names.length > 0 && (
                  <div className="mt-4 flex flex-wrap gap-2">
                    {a.names.map((n) => (
                      <span
                        key={n}
                        className={`rounded-full border ${a.border} bg-reactor-surface/40 px-3 py-1 font-mono text-[10px] uppercase tracking-[0.15em] ${a.accent}`}
                      >
                        {n}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        <div className="reveal mx-auto mt-10 flex max-w-2xl items-center justify-center gap-3 text-center">
          <Quote size={16} className="shrink-0 text-reactor-cyan/60" />
          <p className="text-sm italic leading-relaxed text-reactor-text/65">
            Every achievement begins with someone who believes in you.
          </p>
        </div>
      </div>
    </section>
  );
}

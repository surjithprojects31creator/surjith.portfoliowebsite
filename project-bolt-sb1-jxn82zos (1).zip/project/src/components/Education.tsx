import { GraduationCap, BookOpen, MapPin } from 'lucide-react';

export default function Education() {
  return (
    <section id="education" className="relative py-24 sm:py-32">
      <div className="absolute inset-0 grid-bg opacity-30" />
      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <div className="reveal mb-14 text-center">
          <p className="section-eyebrow">// 04 — ACADEMIC TRACK</p>
          <h2 className="section-title mt-3">EDUCATION</h2>
          <div className="mx-auto mt-4 h-px w-24 bg-gradient-to-r from-transparent via-reactor-cyan to-transparent" />
          <p className="mx-auto mt-4 max-w-xl text-sm text-reactor-text/60">
            The current educational journey. No grades or awards are listed — only what&apos;s verified.
          </p>
        </div>

        <div className="reveal relative mx-auto max-w-3xl">
          {/* Vertical line */}
          <div className="absolute left-5 top-2 h-full w-px bg-gradient-to-b from-reactor-cyan via-reactor-cyan/40 to-transparent sm:left-1/2" />

          <div className="relative pl-14 sm:pl-0">
            <div className="relative sm:grid sm:grid-cols-2 sm:gap-8">
              {/* Node marker */}
              <span className="absolute -left-[34px] top-1 flex h-6 w-6 items-center justify-center rounded-full border border-reactor-cyan/60 bg-reactor-bg sm:left-1/2 sm:-translate-x-1/2">
                <span className="h-2 w-2 animate-pulse rounded-full bg-reactor-cyan shadow-[0_0_10px_2px_rgba(34,211,238,0.8)]" />
              </span>

              <div className="sm:col-start-2">
                <div className="hud-panel p-6 transition-all duration-300 hover:border-reactor-cyan/50 hover:shadow-[0_0_30px_-10px_rgba(34,211,238,0.5)]">
                  <div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.25em] text-reactor-cyan/80">
                    <GraduationCap size={14} /> CURRENT
                  </div>
                  <h3 className="mt-3 font-display text-xl font-bold text-white">
                    Sri Sankara Vidyalayaa, Karur
                  </h3>
                  <div className="mt-2 flex flex-wrap gap-2">
                    <span className="inline-flex items-center gap-1.5 rounded-md border border-reactor-line/60 bg-reactor-surface/50 px-2.5 py-1 font-mono text-[10px] uppercase tracking-wider text-reactor-text/70">
                      <BookOpen size={12} className="text-reactor-cyan" /> CBSE
                    </span>
                    <span className="inline-flex items-center gap-1.5 rounded-md border border-reactor-line/60 bg-reactor-surface/50 px-2.5 py-1 font-mono text-[10px] uppercase tracking-wider text-reactor-text/70">
                      <MapPin size={12} className="text-reactor-cyan" /> Karur
                    </span>
                  </div>
                  <p className="mt-4 text-sm leading-relaxed text-reactor-text/70">
                    Currently studying at Sri Sankara Vidyalayaa under the CBSE board — building
                    foundations in science and mathematics alongside hands-on technology projects.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <p className="mt-8 text-center font-mono text-[10px] uppercase tracking-[0.3em] text-reactor-text/40">
            &gt; NEXT NODE: LOADING...
          </p>
        </div>
      </div>
    </section>
  );
}

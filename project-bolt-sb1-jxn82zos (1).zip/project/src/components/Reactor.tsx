import { useEffect, useState } from 'react';

const SYSTEM_LABELS = [
  'REACTOR ONLINE',
  'POWER LEVEL: ACTIVE',
  'SYSTEM STATUS: OPERATIONAL',
  'MODE: ENGINEERING',
];

const ORBITAL_TAGS = ['ROBOTICS', 'AUTOMATION', 'C / C++', 'ENGINEERING'];

type Props = {
  size?: number;
  interactive?: boolean;
  className?: string;
};

export default function Reactor({ size = 520, interactive = true, className = '' }: Props) {
  const [pulse, setPulse] = useState(0);
  const [labelIdx, setLabelIdx] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setPulse((p) => (p + 1) % 100), 1400);
    const l = setInterval(() => setLabelIdx((i) => (i + 1) % SYSTEM_LABELS.length), 2600);
    return () => {
      clearInterval(t);
      clearInterval(l);
    };
  }, []);

  const c = size / 2;

  return (
    <div
      className={`relative ${className}`}
      style={{ width: size, height: size }}
      aria-hidden="true"
    >
      {/* Ambient glow */}
      <div
        className="absolute inset-0 rounded-full blur-3xl"
        style={{
          background:
            'radial-gradient(circle, rgba(34,211,238,0.22), rgba(59,130,246,0.10) 45%, transparent 70%)',
        }}
      />

      <svg
        viewBox={`0 0 ${size} ${size}`}
        className="absolute inset-0 h-full w-full"
        style={{ filter: 'drop-shadow(0 0 24px rgba(34,211,238,0.35))' }}
      >
        <defs>
          <radialGradient id="core" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#ffffff" />
            <stop offset="25%" stopColor="#67e8f9" />
            <stop offset="55%" stopColor="#22d3ee" />
            <stop offset="100%" stopColor="#0e7490" />
          </radialGradient>
          <radialGradient id="halo" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="rgba(103,232,249,0.55)" />
            <stop offset="60%" stopColor="rgba(34,211,238,0.18)" />
            <stop offset="100%" stopColor="transparent" />
          </radialGradient>
          <linearGradient id="ring" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#22d3ee" />
            <stop offset="50%" stopColor="#3b82f6" />
            <stop offset="100%" stopColor="#22d3ee" />
          </linearGradient>
        </defs>

        {/* Outer dashed ring */}
        <g className="origin-center animate-spin-slower" style={{ transformOrigin: `${c}px ${c}px` }}>
          <circle
            cx={c}
            cy={c}
            r={size * 0.485}
            fill="none"
            stroke="rgba(34,211,238,0.35)"
            strokeWidth="1"
            strokeDasharray="2 10"
          />
          <circle
            cx={c}
            cy={c}
            r={size * 0.46}
            fill="none"
            stroke="rgba(59,130,246,0.25)"
            strokeWidth="1"
          />
        </g>

        {/* Tick ring */}
        <g className="origin-center animate-spin-reverse-slow" style={{ transformOrigin: `${c}px ${c}px` }}>
          {Array.from({ length: 72 }).map((_, i) => {
            const a = (i / 72) * Math.PI * 2;
            const r1 = size * 0.435;
            const r2 = size * 0.45 * (i % 6 === 0 ? 1 : 0.85);
            return (
              <line
                key={i}
                x1={c + Math.cos(a) * r1}
                y1={c + Math.sin(a) * r1}
                x2={c + Math.cos(a) * r2}
                y2={c + Math.sin(a) * r2}
                stroke={i % 6 === 0 ? 'rgba(34,211,238,0.7)' : 'rgba(34,211,238,0.3)'}
                strokeWidth={i % 6 === 0 ? 1.5 : 1}
              />
            );
          })}
        </g>

        {/* Mid ring with segments */}
        <g className="origin-center animate-spin-slow" style={{ transformOrigin: `${c}px ${c}px` }}>
          <circle
            cx={c}
            cy={c}
            r={size * 0.39}
            fill="none"
            stroke="url(#ring)"
            strokeWidth="2"
            strokeDasharray="40 18 90 18"
            opacity="0.8"
          />
          {Array.from({ length: 8 }).map((_, i) => {
            const a = (i / 8) * Math.PI * 2 - Math.PI / 2;
            const r = size * 0.39;
            return (
              <circle
                key={i}
                cx={c + Math.cos(a) * r}
                cy={c + Math.sin(a) * r}
                r="3"
                fill="#22d3ee"
                style={{ filter: 'drop-shadow(0 0 4px #22d3ee)' }}
              />
            );
          })}
        </g>

        {/* Inner reverse ring */}
        <g className="origin-center animate-spin-reverse" style={{ transformOrigin: `${c}px ${c}px` }}>
          <circle
            cx={c}
            cy={c}
            r={size * 0.31}
            fill="none"
            stroke="rgba(103,232,249,0.5)"
            strokeWidth="1.5"
            strokeDasharray="120 30"
          />
        </g>

        {/* Triangular reactor frame */}
        <g className="origin-center animate-spin-slow" style={{ transformOrigin: `${c}px ${c}px` }}>
          <polygon
            points={`${c},${c - size * 0.26} ${c + size * 0.225},${c + size * 0.13} ${c - size * 0.225},${c + size * 0.13}`}
            fill="none"
            stroke="rgba(34,211,238,0.6)"
            strokeWidth="2"
          />
          <polygon
            points={`${c},${c + size * 0.26} ${c + size * 0.225},${c - size * 0.13} ${c - size * 0.225},${c - size * 0.13}`}
            fill="none"
            stroke="rgba(59,130,246,0.45)"
            strokeWidth="1.5"
          />
        </g>

        {/* Halo */}
        <circle cx={c} cy={c} r={size * 0.2} fill="url(#halo)" className="animate-pulse-core" />

        {/* Energy core */}
        <g>
          <circle
            cx={c}
            cy={c}
            r={size * (0.115 + (pulse % 2 === 0 ? 0.004 : 0))}
            fill="url(#core)"
            className="animate-pulse-core"
            style={{ filter: 'drop-shadow(0 0 16px rgba(103,232,249,0.9))' }}
          />
          <circle cx={c} cy={c} r={size * 0.06} fill="#ffffff" opacity="0.9" />
        </g>

        {/* Crosshair lines */}
        <g stroke="rgba(34,211,238,0.25)" strokeWidth="1">
          <line x1={c} y1={size * 0.02} x2={c} y2={size * 0.1} />
          <line x1={c} y1={size * 0.9} x2={c} y2={size * 0.98} />
          <line x1={size * 0.02} y1={c} x2={size * 0.1} y2={c} />
          <line x1={size * 0.9} y1={c} x2={size * 0.98} y2={c} />
        </g>
      </svg>

      {/* Orbiting tags */}
      {interactive &&
        ORBITAL_TAGS.map((tag, i) => {
          const a = (i / ORBITAL_TAGS.length) * Math.PI * 2 - Math.PI / 2;
          const r = size * 0.5;
          return (
            <span
              key={tag}
              className="absolute font-mono text-[10px] uppercase tracking-[0.25em] text-reactor-cyan/70"
              style={{
                left: `${50 + Math.cos(a) * r * 0.92}%`,
                top: `${50 + Math.sin(a) * r * 0.92}%`,
                transform: 'translate(-50%, -50%)',
              }}
            >
              {tag}
            </span>
          );
        })}

      {/* System status chip */}
      {interactive && (
        <div className="absolute left-1/2 top-full mt-3 -translate-x-1/2 whitespace-nowrap font-mono text-[10px] uppercase tracking-[0.3em] text-reactor-cyan/70 transition-opacity">
          <span className="mr-1 inline-block h-1.5 w-1.5 animate-pulse rounded-full bg-reactor-green" />
          {SYSTEM_LABELS[labelIdx]}
        </div>
      )}
    </div>
  );
}

import { Rocket, BookOpen, Heart, Sparkles } from 'lucide-react';

const PILLARS = [
  { icon: Rocket, title: 'Vision', text: 'Dreaming big and imagining a stronger future for India through science.' },
  { icon: BookOpen, title: 'Scientific Thinking', text: 'Approaching problems with curiosity, logic and disciplined inquiry.' },
  { icon: Heart, title: 'Humility & Dedication', text: 'Staying grounded and committed to work, regardless of recognition.' },
  { icon: Sparkles, title: 'Service Through Knowledge', text: 'Using what I learn to contribute to society, not just myself.' },
];

export default function Inspiration() {
  return (
    <section id="inspiration" className="relative overflow-hidden py-24 sm:py-32">
      <div className="absolute inset-0 grid-bg opacity-30" />
      <div
        className="absolute inset-0"
        style={{ background: 'radial-gradient(ellipse at 50% 40%, rgba(245,158,11,0.10), transparent 55%)' }}
      />
      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <div className="reveal mb-14 text-center">
          <p className="section-eyebrow" style={{ color: 'rgba(245,158,11,0.8)' }}>
            // 05 — GUIDANCE SYSTEM
          </p>
          <h2 className="section-title mt-3">INSPIRATION</h2>
          <div className="mx-auto mt-4 h-px w-24 bg-gradient-to-r from-transparent via-reactor-amber to-transparent" />
        </div>

        <div className="reveal mx-auto max-w-3xl text-center">
          <p className="font-mono text-xs uppercase tracking-[0.4em] text-reactor-amber/80">
            DR. A. P. J. ABDUL KALAM
          </p>
          <h3 className="mt-4 font-display text-3xl font-extrabold tracking-tight text-white sm:text-4xl md:text-5xl">
            DREAM. <span className="text-reactor-amber glow-text">LEARN.</span> BUILD. SERVE.
          </h3>
          <p className="mx-auto mt-6 max-w-2xl text-base leading-relaxed text-reactor-text/75">
            Dr. A. P. J. Abdul Kalam inspires me through his vision, scientific thinking, dedication
            and humility. His life — from a small town to the heart of India&apos;s space and missile
            programs, and then to the Presidency — shows that curiosity and hard work can take you
            anywhere. His dream of a stronger, self-reliant India motivates me to learn science and
            technology, dream bigger, and use knowledge to contribute to society.
          </p>
        </div>

        <div className="reveal mx-auto mt-12 grid max-w-4xl gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {PILLARS.map((p, i) => (
            <div
              key={p.title}
              style={{ animationDelay: `${i * 60}ms` }}
              className="group rounded-xl border border-reactor-amber/25 bg-reactor-panel/40 p-5 text-center transition-all duration-300 hover:-translate-y-1 hover:border-reactor-amber/50 hover:bg-reactor-amber/5"
            >
              <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full border border-reactor-amber/40 bg-reactor-amber/10 text-reactor-amber transition-transform group-hover:scale-110">
                <p.icon size={22} />
              </div>
              <h4 className="mt-4 font-display text-sm font-bold uppercase tracking-wider text-white">
                {p.title}
              </h4>
              <p className="mt-2 text-xs leading-relaxed text-reactor-text/65">{p.text}</p>
            </div>
          ))}
        </div>

        <blockquote className="reveal mx-auto mt-12 max-w-2xl border-l-2 border-reactor-amber/50 pl-5 text-sm italic leading-relaxed text-reactor-text/70">
          &ldquo;You have to dream before your dreams can come true.&rdquo;
          <footer className="mt-2 not-italic font-mono text-[10px] uppercase tracking-[0.25em] text-reactor-amber/70">
            — Dr. A. P. J. Abdul Kalam
          </footer>
        </blockquote>
      </div>
    </section>
  );
}

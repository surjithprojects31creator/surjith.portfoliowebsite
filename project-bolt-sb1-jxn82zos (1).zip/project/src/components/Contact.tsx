import { useState } from 'react';
import { Mail, Github, Instagram, Send, CheckCircle2 } from 'lucide-react';

const LINKS = [
  { icon: Mail, label: 'EMAIL', href: 'mailto:surjithdeveloper31@gmail.com', display: 'surjithdeveloper31@gmail.com' },
  { icon: Github, label: 'GITHUB', href: 'https://github.com/surjith0208', display: 'github.com/surjith0208' },
];

export default function Contact() {
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', message: '' });

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
    setTimeout(() => {
      setSent(false);
      setForm({ name: '', email: '', message: '' });
    }, 3500);
  };

  return (
    <section id="contact" className="relative py-24 sm:py-32">
      <div className="absolute inset-0 grid-bg opacity-30" />
      <div
        className="absolute inset-0"
        style={{ background: 'radial-gradient(ellipse at 50% 50%, rgba(34,211,238,0.10), transparent 55%)' }}
      />
      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <div className="reveal mb-14 text-center">
          <p className="section-eyebrow">// 08 — OPEN CHANNEL</p>
          <h2 className="section-title mt-3">CONTACT</h2>
          <div className="mx-auto mt-4 h-px w-24 bg-gradient-to-r from-transparent via-reactor-cyan to-transparent" />
          <h3 className="mx-auto mt-6 max-w-2xl font-display text-2xl font-bold text-white sm:text-3xl">
            LET&apos;S BUILD SOMETHING.
          </h3>
        </div>

        <div className="grid gap-8 lg:grid-cols-[0.9fr_1.1fr]">
          {/* Links */}
          <div className="reveal flex flex-col gap-3">
            {LINKS.map((l) => (
              <a
                key={l.label}
                href={l.href}
                className="group flex items-center gap-4 rounded-xl border border-reactor-line/60 bg-reactor-panel/40 p-5 transition-all duration-300 hover:border-reactor-cyan/50 hover:bg-reactor-cyan/5"
              >
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg border border-reactor-cyan/30 bg-reactor-cyan/10 text-reactor-cyan transition-transform group-hover:scale-110">
                  <l.icon size={20} />
                </div>
                <div className="min-w-0">
                  <div className="font-mono text-[10px] uppercase tracking-[0.25em] text-reactor-text/50">
                    {l.label}
                  </div>
                  <div className="truncate text-sm text-reactor-text/80 group-hover:text-reactor-glow">
                    {l.display}
                  </div>
                </div>
              </a>
            ))}
            <a
              href="https://instagram.com/surjith0208"
              target="_blank"
              rel="noopener noreferrer"
              className="group flex items-center gap-4 rounded-xl border border-reactor-line/60 bg-reactor-panel/40 p-5 transition-all duration-300 hover:border-reactor-cyan/50 hover:bg-reactor-cyan/5"
            >
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg border border-reactor-cyan/30 bg-reactor-cyan/10 text-reactor-cyan transition-transform group-hover:scale-110">
                <Instagram size={20} />
              </div>
              <div className="min-w-0">
                <div className="font-mono text-[10px] uppercase tracking-[0.25em] text-reactor-text/50">
                  INSTAGRAM
                </div>
                <div className="truncate text-sm text-reactor-text/80 group-hover:text-reactor-glow">
                  instagram.com/surjith0208
                </div>
              </div>
            </a>
          </div>

          {/* Form */}
          <form
            onSubmit={onSubmit}
            className="reveal relative overflow-hidden rounded-xl border border-reactor-line/60 bg-reactor-panel/50 p-6 sm:p-8"
          >
            <span className="hud-corner left-2 top-2 border-l border-t" />
            <span className="hud-corner right-2 top-2 border-r border-t" />
            <span className="hud-corner left-2 bottom-2 border-l border-b" />
            <span className="hud-corner right-2 bottom-2 border-r border-b" />

            <div className="mb-4 font-mono text-[10px] uppercase tracking-[0.25em] text-reactor-cyan/70">
              &gt; TRANSMISSION FORM
            </div>

            <div className="space-y-4">
              <Field
                label="NAME"
                value={form.name}
                onChange={(v) => setForm({ ...form, name: v })}
                placeholder="Your name"
                type="text"
              />
              <Field
                label="EMAIL"
                value={form.email}
                onChange={(v) => setForm({ ...form, email: v })}
                placeholder="your.email@example.com"
                type="email"
              />
              <div>
                <label className="mb-1.5 block font-mono text-[10px] uppercase tracking-[0.25em] text-reactor-text/60">
                  MESSAGE
                </label>
                <textarea
                  required
                  rows={4}
                  value={form.message}
                  onChange={(e) => setForm({ ...form, message: e.target.value })}
                  placeholder="Tell me about your idea, question or collaboration..."
                  className="w-full resize-none rounded-lg border border-reactor-line/60 bg-reactor-bg/60 px-4 py-3 text-sm text-reactor-text placeholder:text-reactor-text/30 focus:border-reactor-cyan/60 focus:outline-none focus:ring-1 focus:ring-reactor-cyan/40"
                />
              </div>

              <button
                type="submit"
                disabled={sent}
                className={`btn-primary w-full justify-center ${sent ? 'border-reactor-green/60 text-reactor-green' : ''}`}
              >
                {sent ? (
                  <>
                    <CheckCircle2 size={15} /> MESSAGE SENT
                  </>
                ) : (
                  <>
                    <Send size={15} /> SEND MESSAGE
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </section>
  );
}

function Field({
  label,
  value,
  onChange,
  placeholder,
  type,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder: string;
  type: string;
}) {
  return (
    <div>
      <label className="mb-1.5 block font-mono text-[10px] uppercase tracking-[0.25em] text-reactor-text/60">
        {label}
      </label>
      <input
        required
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full rounded-lg border border-reactor-line/60 bg-reactor-bg/60 px-4 py-3 text-sm text-reactor-text placeholder:text-reactor-text/30 focus:border-reactor-cyan/60 focus:outline-none focus:ring-1 focus:ring-reactor-cyan/40"
      />
    </div>
  );
}

import { useState } from 'react';
import { PROJECTS, type Project } from '@/data/projects';
import { ArrowUpRight, X, Cpu, Target, Wrench, Code2, Activity, CheckCircle2, Github } from 'lucide-react';

const ACCENT: Record<Project['accent'], { text: string; border: string; glow: string; bg: string }> = {
  cyan: { text: 'text-reactor-cyan', border: 'border-reactor-cyan/40', glow: 'shadow-[0_0_30px_-8px_rgba(34,211,238,0.6)]', bg: 'bg-reactor-cyan/10' },
  blue: { text: 'text-reactor-blue', border: 'border-reactor-blue/40', glow: 'shadow-[0_0_30px_-8px_rgba(59,130,246,0.6)]', bg: 'bg-reactor-blue/10' },
  amber: { text: 'text-reactor-amber', border: 'border-reactor-amber/40', glow: 'shadow-[0_0_30px_-8px_rgba(245,158,11,0.6)]', bg: 'bg-reactor-amber/10' },
  red: { text: 'text-reactor-red', border: 'border-reactor-red/40', glow: 'shadow-[0_0_30px_-8px_rgba(239,68,68,0.6)]', bg: 'bg-reactor-red/10' },
};

function ProjectDiagram({ project }: { project: Project }) {
  const nodes = project.hardware.slice(0, 4);
  return (
    <div className="relative flex flex-col items-center gap-3 rounded-xl border border-reactor-line/50 bg-reactor-surface/40 p-5">
      <div className="font-mono text-[10px] uppercase tracking-[0.3em] text-reactor-text/50">
        SYSTEM ARCHITECTURE
      </div>
      <div className="flex flex-wrap items-center justify-center gap-2">
        {nodes.map((h, i) => (
          <div key={h} className="flex items-center gap-2">
            <div className={`rounded-md border ${ACCENT[project.accent].border} ${ACCENT[project.accent].bg} px-3 py-2 text-center`}>
              <div className="font-mono text-[10px] uppercase tracking-wider text-reactor-text/80">{h}</div>
            </div>
            {i < nodes.length - 1 && (
              <span className="text-reactor-cyan/60">→</span>
            )}
          </div>
        ))}
      </div>
      <div className="mt-1 flex items-center gap-2 rounded-md border border-reactor-cyan/30 bg-reactor-cyan/10 px-4 py-2">
        <Cpu size={14} className="text-reactor-cyan" />
        <span className="font-mono text-[10px] uppercase tracking-wider text-reactor-glow">
          {project.software[0] ?? 'CONTROL LOGIC'}
        </span>
      </div>
    </div>
  );
}

function ProjectDetail({ project, onClose }: { project: Project; onClose: () => void }) {
  const a = ACCENT[project.accent];
  return (
    <div
      className="fixed inset-0 z-[60] flex items-start justify-center overflow-y-auto bg-reactor-bg/80 p-4 backdrop-blur-md sm:p-8"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-3xl rounded-2xl border border-reactor-line/60 bg-reactor-panel/95 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <span className={`hud-corner left-3 top-3 border-l border-t ${a.text}`} />
        <span className={`hud-corner right-3 top-3 border-r border-t ${a.text}`} />
        <span className={`hud-corner left-3 bottom-3 border-l border-b ${a.text}`} />
        <span className={`hud-corner right-3 bottom-3 border-r border-b ${a.text}`} />

        <button
          onClick={onClose}
          className="absolute right-4 top-4 flex h-9 w-9 items-center justify-center rounded-md border border-reactor-line/60 text-reactor-text/70 transition-colors hover:border-reactor-cyan/50 hover:text-reactor-glow"
          aria-label="Close project details"
        >
          <X size={18} />
        </button>

        <div className="p-6 sm:p-9">
          <div className="flex flex-wrap items-center gap-3">
            <span className={`rounded-full border ${a.border} ${a.bg} px-3 py-1 font-mono text-[10px] uppercase tracking-[0.2em] ${a.text}`}>
              {project.status}
            </span>
            <span className="font-mono text-[10px] uppercase tracking-[0.2em] text-reactor-text/50">
              {project.category}
            </span>
          </div>

          <h3 className="mt-4 font-display text-2xl font-bold text-white sm:text-3xl">
            {project.name}
          </h3>
          <p className="mt-2 text-sm text-reactor-text/70">{project.tagline}</p>

          <div className="mt-5">
            <ProjectDiagram project={project} />
          </div>

          <div className="mt-6 grid gap-5 sm:grid-cols-2">
            <Block icon={Target} label="MISSION" text={project.mission} accent={a.text} />
            <Block icon={Activity} label="OBJECTIVE" text={project.objective} accent={a.text} />
          </div>

          <div className="mt-5 grid gap-5 sm:grid-cols-2">
            <ListBlock icon={Wrench} label="HARDWARE" items={project.hardware} accent={a.text} />
            <ListBlock icon={Code2} label="SOFTWARE" items={project.software} accent={a.text} />
          </div>

          <div className="mt-5">
            <div className={`mb-2 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.25em] ${a.text}`}>
              <Activity size={13} /> HOW IT WORKS
            </div>
            <ol className="space-y-2">
              {project.howItWorks.map((step, i) => (
                <li key={i} className="flex gap-3 text-sm text-reactor-text/80">
                  <span className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full border ${a.border} ${a.bg} font-mono text-[10px] ${a.text}`}>
                    {i + 1}
                  </span>
                  {step}
                </li>
              ))}
            </ol>
          </div>

          <div className="mt-5 rounded-xl border border-reactor-green/30 bg-reactor-green/5 p-5">
            <div className="mb-2 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.25em] text-reactor-green">
              <CheckCircle2 size={13} /> RESULT
            </div>
            <p className="text-sm leading-relaxed text-reactor-text/85">{project.result}</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Block({ icon: Icon, label, text, accent }: { icon: typeof Target; label: string; text: string; accent: string }) {
  return (
    <div className="rounded-xl border border-reactor-line/50 bg-reactor-surface/40 p-4">
      <div className={`mb-1.5 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.25em] ${accent}`}>
        <Icon size={13} /> {label}
      </div>
      <p className="text-sm leading-relaxed text-reactor-text/80">{text}</p>
    </div>
  );
}

function ListBlock({ icon: Icon, label, items, accent }: { icon: typeof Wrench; label: string; items: string[]; accent: string }) {
  return (
    <div className="rounded-xl border border-reactor-line/50 bg-reactor-surface/40 p-4">
      <div className={`mb-2 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.25em] ${accent}`}>
        <Icon size={13} /> {label}
      </div>
      <ul className="space-y-1.5">
        {items.map((it) => (
          <li key={it} className="flex items-start gap-2 text-sm text-reactor-text/80">
            <span className={`mt-1.5 h-1 w-1 shrink-0 rounded-full ${accent.replace('text-', 'bg-')}`} />
            {it}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default function Projects() {
  const [selected, setSelected] = useState<Project | null>(null);

  return (
    <section id="projects" className="relative py-24 sm:py-32">
      <div className="absolute inset-0 grid-bg opacity-30" />
      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <div className="reveal mb-14 text-center">
          <p className="section-eyebrow">// 03 — BUILD LOG</p>
          <h2 className="section-title mt-3">PROJECTS</h2>
          <div className="mx-auto mt-4 h-px w-24 bg-gradient-to-r from-transparent via-reactor-cyan to-transparent" />
          <p className="mx-auto mt-4 max-w-xl text-sm text-reactor-text/60">
            Select any project to open its mission file — objective, hardware, software &amp; results.
          </p>
        </div>

        <div className="reveal grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {PROJECTS.map((p, i) => {
            const a = ACCENT[p.accent];
            return (
              <button
                key={p.id}
                onClick={() => setSelected(p)}
                style={{ animationDelay: `${i * 50}ms` }}
                className={`group relative flex flex-col overflow-hidden rounded-xl border ${a.border} bg-reactor-panel/40 p-5 text-left transition-all duration-300 hover:-translate-y-1.5 hover:bg-reactor-panel/70 ${a.glow}`}
              >
                {/* Diagram preview */}
                <div className="relative mb-4 h-32 overflow-hidden rounded-lg border border-reactor-line/40 bg-reactor-bg/60">
                  <div className="absolute inset-0 grid-bg opacity-40" />
                  <svg viewBox="0 0 300 120" className="h-full w-full">
                    <g className="origin-center animate-spin-slow" style={{ transformOrigin: '150px 60px' }}>
                      <circle cx="150" cy="60" r="34" fill="none" stroke="currentColor" strokeWidth="1.5" strokeDasharray="30 14" className={a.text} opacity="0.6" />
                    </g>
                    <circle cx="150" cy="60" r="14" fill="currentColor" className={a.text} opacity="0.25" />
                    <circle cx="150" cy="60" r="6" fill="currentColor" className={a.text} />
                    {Array.from({ length: 6 }).map((_, k) => {
                      const ang = (k / 6) * Math.PI * 2;
                      return (
                        <line key={k} x1={150 + Math.cos(ang) * 40} y1={60 + Math.sin(ang) * 40} x2={150 + Math.cos(ang) * 52} y2={60 + Math.sin(ang) * 52} stroke="currentColor" strokeWidth="1" className={a.text} opacity="0.5" />
                      );
                    })}
                  </svg>
                  <span className={`absolute left-2 top-2 rounded-full border ${a.border} ${a.bg} px-2 py-0.5 font-mono text-[8px] uppercase tracking-wider ${a.text}`}>
                    {p.status}
                  </span>
                </div>

                <h3 className="font-display text-base font-bold leading-snug text-white">
                  {p.name}
                </h3>
                <p className="mt-1.5 text-xs leading-relaxed text-reactor-text/65">{p.tagline}</p>

                <div className="mt-3 flex flex-wrap gap-1.5">
                  {p.tech.slice(0, 4).map((t) => (
                    <span key={t} className="rounded border border-reactor-line/60 bg-reactor-surface/50 px-2 py-0.5 font-mono text-[9px] uppercase tracking-wider text-reactor-text/60">
                      {t}
                    </span>
                  ))}
                </div>

                <div className="mt-4 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.2em] text-reactor-cyan/80">
                  VIEW PROJECT
                  <ArrowUpRight size={13} className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                </div>
              </button>
            );
          })}
        </div>

        <div className="reveal mt-10 flex flex-wrap items-center justify-between gap-4 rounded-xl border border-reactor-line/50 bg-reactor-surface/30 px-6 py-5">
          <div className="flex items-center gap-3">
            <Github size={18} className="text-reactor-cyan" />
            <div>
              <div className="font-display text-sm font-semibold text-white">EXPERIMENTS &amp; PROTOTYPES</div>
              <div className="text-xs text-reactor-text/60">RGB LEDs, sensors, buzzers &amp; small circuits — ongoing learning builds.</div>
            </div>
          </div>
          <span className="font-mono text-[10px] uppercase tracking-[0.25em] text-reactor-text/50">
            ACTIVE ITERATION
          </span>
        </div>
      </div>

      {selected && <ProjectDetail project={selected} onClose={() => setSelected(null)} />}
    </section>
  );
}

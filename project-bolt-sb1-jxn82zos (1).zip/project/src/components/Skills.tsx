import { useState } from 'react';
import {
  Cpu, CircuitBoard, Bot, Zap, Radio, Wifi, Microchip, Code2,
  Wrench, Spline, Gauge, Cog,
} from 'lucide-react';

type Skill = {
  name: string;
  icon: typeof Cpu;
  desc: string;
  level: 'core' | 'hardware' | 'systems';
};

const SKILLS: Skill[] = [
  { name: 'C', icon: Code2, desc: 'Procedural programming foundation for embedded & systems work.', level: 'core' },
  { name: 'C++', icon: Code2, desc: 'Object-oriented programming for complex logic & data structures.', level: 'core' },
  { name: 'Programming', icon: Cpu, desc: 'General problem-solving & algorithmic thinking.', level: 'core' },
  { name: 'Robotics', icon: Bot, desc: 'Designing motion, control logic & mechanical behavior.', level: 'core' },
  { name: 'Automation', icon: Zap, desc: 'Automating tasks with sensors, logic & control flow.', level: 'core' },
  { name: 'Arduino', icon: Microchip, desc: 'Prototyping interactive hardware with Arduino boards.', level: 'hardware' },
  { name: 'ESP32', icon: Wifi, desc: 'Wi-Fi/BLE-enabled microcontroller for connected builds.', level: 'hardware' },
  { name: 'IoT', icon: Radio, desc: 'Connecting devices & sensors to the network & cloud.', level: 'hardware' },
  { name: 'Embedded Systems', icon: Cpu, desc: 'Firmware & low-level control on microcontrollers.', level: 'systems' },
  { name: 'Electronics', icon: CircuitBoard, desc: 'Understanding components, signals & power flow.', level: 'hardware' },
  { name: 'Hardware Prototyping', icon: Wrench, desc: 'Breadboarding, soldering & iterating on designs.', level: 'hardware' },
  { name: 'Circuit Design', icon: Spline, desc: 'Schematics, wiring & sensor integration layouts.', level: 'hardware' },
  { name: 'Sensors', icon: Gauge, desc: 'Reading the physical world: IR, camera, distance & more.', level: 'systems' },
  { name: 'Microcontrollers', icon: Cog, desc: 'Working with MCUs to drive real-world hardware.', level: 'systems' },
];

const LEVEL_META = {
  core: { label: 'CORE', color: 'text-reactor-cyan', ring: 'border-reactor-cyan/40' },
  hardware: { label: 'HARDWARE', color: 'text-reactor-blue', ring: 'border-reactor-blue/40' },
  systems: { label: 'SYSTEMS', color: 'text-reactor-amber', ring: 'border-reactor-amber/40' },
} as const;

export default function Skills() {
  const [active, setActive] = useState<Skill | null>(null);

  return (
    <section id="skills" className="relative py-24 sm:py-32">
      <div className="absolute inset-0 grid-bg opacity-30" />
      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <div className="reveal mb-14 text-center">
          <p className="section-eyebrow">// 02 — CAPABILITY MATRIX</p>
          <h2 className="section-title mt-3">SKILLS</h2>
          <div className="mx-auto mt-4 h-px w-24 bg-gradient-to-r from-transparent via-reactor-cyan to-transparent" />
          <p className="mx-auto mt-4 max-w-xl text-sm text-reactor-text/60">
            Hover a node to inspect its specification. Categorized by domain.
          </p>
        </div>

        <div className="reveal grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 lg:grid-cols-5">
          {SKILLS.map((s, i) => {
            const meta = LEVEL_META[s.level];
            return (
              <button
                key={s.name}
                onMouseEnter={() => setActive(s)}
                onMouseLeave={() => setActive(null)}
                onFocus={() => setActive(s)}
                style={{ animationDelay: `${i * 30}ms` }}
                className={`group relative flex aspect-square flex-col items-center justify-center gap-2 rounded-xl border ${meta.ring} bg-reactor-panel/40 p-3 text-center transition-all duration-300 hover:-translate-y-1 hover:bg-reactor-cyan/5 hover:shadow-[0_0_24px_-6px_rgba(34,211,238,0.5)]`}
              >
                <s.icon size={26} className={`${meta.color} transition-transform group-hover:scale-110`} />
                <span className="font-mono text-[10px] font-semibold uppercase tracking-[0.12em] text-reactor-text sm:text-xs">
                  {s.name}
                </span>
                <span className={`font-mono text-[8px] uppercase tracking-[0.2em] ${meta.color} opacity-70`}>
                  {meta.label}
                </span>
                <span className="pointer-events-none absolute inset-x-3 bottom-2 h-px bg-gradient-to-r from-transparent via-reactor-cyan/40 to-transparent opacity-0 transition-opacity group-hover:opacity-100" />
              </button>
            );
          })}
        </div>

        {/* Description HUD */}
        <div className="reveal mt-6 flex min-h-[64px] items-center rounded-xl border border-reactor-line/60 bg-reactor-surface/50 px-5 py-4">
          {active ? (
            <p className="text-sm text-reactor-text/80">
              <span className={`font-mono text-xs font-semibold uppercase tracking-[0.2em] ${LEVEL_META[active.level].color}`}>
                {active.name} ::{' '}
              </span>
              {active.desc}
            </p>
          ) : (
            <p className="font-mono text-xs uppercase tracking-[0.25em] text-reactor-text/40">
              &gt; Awaiting input... select a node to read its specification.
            </p>
          )}
        </div>
      </div>
    </section>
  );
}

export type Project = {
  id: string;
  name: string;
  tagline: string;
  category: string;
  status: 'PROTOTYPE' | 'CONCEPT' | 'EXPERIMENT';
  tech: string[];
  mission: string;
  objective: string;
  hardware: string[];
  software: string[];
  howItWorks: string[];
  result: string;
  accent: 'cyan' | 'blue' | 'amber' | 'red';
};

export const PROJECTS: Project[] = [
  {
    id: 'bus-iot',
    name: 'School Bus Attendance & Safety IoT System',
    tagline: 'Intelligent school transportation safety & attendance system.',
    category: 'IoT · Computer Vision',
    status: 'CONCEPT',
    tech: ['Raspberry Pi', 'Camera', 'Face Recognition', 'QR', 'GPS', 'IoT'],
    mission: 'Make school bus travel safer and attendance automatic.',
    objective:
      'Detect which students boarded the bus, verify identity, track the bus in real time, and notify parents — reducing manual errors and improving safety.',
    hardware: ['Raspberry Pi', 'Pi Camera', 'GPS Module', 'QR Scanner', 'Buzzer / LED indicators'],
    software: ['Face Recognition (Python)', 'QR verification', 'GPS parsing', 'Parent notification service', 'IoT communication layer'],
    howItWorks: [
      'Camera captures students as they board the bus.',
      'Face recognition matches each face against enrolled student records.',
      'QR code provides a secondary verification fallback.',
      'GPS streams the bus location to a monitoring dashboard.',
      'Parents receive automatic notifications when their child boards/alights.',
    ],
    result:
      'A working concept for safe, automated student attendance and real-time transport visibility — reducing manual effort and improving parent trust.',
    accent: 'cyan',
  },
  {
    id: 'ir-security',
    name: 'Arduino IR Security / Alarm System',
    tagline: 'Multi-sensor intrusion detection with audio-visual alerts.',
    category: 'Security · Electronics',
    status: 'PROTOTYPE',
    tech: ['Arduino', 'IR Sensors', 'Speaker', 'RGB LED'],
    mission: 'Detect intrusion across multiple zones and alert instantly.',
    objective:
      'Use several IR sensors to monitor a space; when motion is detected, trigger an alarm and a colored warning light.',
    hardware: ['Arduino Uno', 'Multiple IR sensors', 'Speaker / Buzzer', 'RGB LED warning light'],
    software: ['Arduino C++ firmware', 'Sensor polling loop', 'Threshold detection logic', 'Alarm + LED control'],
    howItWorks: [
      'IR sensors are placed across entry points.',
      'Arduino continuously polls each sensor.',
      'When a sensor is tripped, the system classifies the zone.',
      'Buzzer sounds the alarm; RGB LED shifts to warning color.',
    ],
    result: 'A reliable, low-cost electronics security prototype demonstrating multi-zone detection.',
    accent: 'red',
  },
  {
    id: 'bt-car',
    name: 'Bluetooth Controlled Robotic Car',
    tagline: 'Wireless joystick-controlled robot over Bluetooth.',
    category: 'Robotics · Wireless',
    status: 'PROTOTYPE',
    tech: ['Arduino', 'HC-05', 'Joystick', 'Motor Driver'],
    mission: 'Build a responsive wireless-controlled robot.',
    objective:
      'Transmit joystick movements from a controller to an Arduino robot car over Bluetooth and drive motors in real time.',
    hardware: ['Arduino', 'HC-05 Bluetooth module', 'Joystick controller', 'Motor driver (L298N)', 'DC motors + chassis'],
    software: ['Arduino C++ firmware', 'Serial Bluetooth protocol', 'Motor direction + speed control'],
    howItWorks: [
      'Joystick readings are sent from the transmitter over HC-05.',
      'Arduino receives commands via serial Bluetooth.',
      'Motor driver translates commands into wheel motion.',
      'Direction and speed map to joystick position.',
    ],
    result: 'A smooth, responsive Bluetooth robot car demonstrating wireless control architecture.',
    accent: 'blue',
  },
  {
    id: 'esp32-cam',
    name: 'ESP32-CAM Surveillance / Recording Project',
    tagline: 'Embedded vision with wireless capture & SD recording.',
    category: 'Embedded Vision',
    status: 'PROTOTYPE',
    tech: ['ESP32-CAM', 'Camera', 'SD Card', 'Wireless'],
    mission: 'Capture and record video from a compact embedded camera.',
    objective:
      'Use an ESP32-CAM to capture images/video, store them to an SD card, and enable wireless access for monitoring.',
    hardware: ['ESP32-CAM module', 'MicroSD card', 'Power supply'],
    software: ['ESP32 camera driver', 'SD card storage', 'Wi-Fi streaming / capture control'],
    howItWorks: [
      'ESP32-CAM initializes the camera sensor.',
      'Frames are captured and written to the SD card.',
      'Wi-Fi allows remote triggering or live view.',
      'Recordings can be retrieved for review.',
    ],
    result: 'A compact embedded vision system showing capture, storage and wireless access on a single board.',
    accent: 'cyan',
  },
  {
    id: 'music',
    name: 'Arduino Musical Instrument',
    tagline: 'Custom electronic instrument with button/sensor input.',
    category: 'Interactive Hardware',
    status: 'EXPERIMENT',
    tech: ['Arduino', 'Buttons', 'Sensors', 'Audio Output'],
    mission: 'Turn buttons and sensors into a playable instrument.',
    objective:
      'Map button presses and sensor values to tones, creating an interactive electronic musical instrument.',
    hardware: ['Arduino', 'Push buttons', 'Sensors (e.g. flex / light)', 'Speaker / piezo buzzer'],
    software: ['Arduino C++ firmware', 'Tone generation', 'Sensor-to-note mapping'],
    howItWorks: [
      'Buttons select notes; sensors modulate pitch or tempo.',
      'Arduino reads inputs in real time.',
      'Tone() generates audio frequencies on the speaker.',
      'Player performs melodies interactively.',
    ],
    result: 'A fun embedded electronics project blending hardware input with audio output.',
    accent: 'amber',
  },
  {
    id: 'rgb-experiments',
    name: 'RGB & Electronics Experiments',
    tagline: 'Small circuits: RGB LEDs, sensors, buzzers & microcontrollers.',
    category: 'Experiments & Prototypes',
    status: 'EXPERIMENT',
    tech: ['RGB LEDs', 'Sensors', 'Arduino', 'Buzzers'],
    mission: 'Explore fundamentals through small, iterative builds.',
    objective:
      'Experiment with RGB LEDs, sensors, buzzers and basic circuits to learn core electronics and microcontroller control.',
    hardware: ['RGB LEDs', 'Assorted sensors', 'Buzzers / speakers', 'Microcontrollers', 'Basic circuit components'],
    software: ['Arduino sketches', 'Sensor reading', 'LED animation logic'],
    howItWorks: [
      'Each experiment isolates one concept (color mixing, sensing, sound).',
      'Code reads sensors and drives outputs accordingly.',
      'Iterative prototyping builds intuition for larger projects.',
    ],
    result: 'A growing library of small prototypes that form the foundation of bigger builds.',
    accent: 'blue',
  },
];

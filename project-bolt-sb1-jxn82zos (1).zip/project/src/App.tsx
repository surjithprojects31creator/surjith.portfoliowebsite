import Navigation from '@/components/Navigation';
import Hero from '@/components/Hero';
import About from '@/components/About';
import Skills from '@/components/Skills';
import Projects from '@/components/Projects';
import Education from '@/components/Education';
import Inspiration from '@/components/Inspiration';
import Languages from '@/components/Languages';
import Gratitude from '@/components/Gratitude';
import Contact from '@/components/Contact';
import Footer from '@/components/Footer';
import CustomCursor from '@/components/CustomCursor';
import useReveal from '@/hooks/useReveal';

function App() {
  useReveal();

  return (
    <div className="relative min-h-screen bg-reactor-bg text-reactor-text">
      <CustomCursor />
      {/* Global ambient backdrop */}
      <div className="pointer-events-none fixed inset-0 z-0">
        <div className="absolute inset-0 grid-bg opacity-20" />
        <div
          className="absolute inset-0"
          style={{
            background:
              'radial-gradient(ellipse at 20% 0%, rgba(34,211,238,0.08), transparent 40%), radial-gradient(ellipse at 80% 100%, rgba(59,130,246,0.06), transparent 45%)',
          }}
        />
      </div>

      <div className="relative z-10">
        <Navigation />
        <main>
          <Hero />
          <About />
          <Skills />
          <Projects />
          <Education />
          <Inspiration />
          <Languages />
          <Gratitude />
          <Contact />
        </main>
        <Footer />
      </div>
    </div>
  );
}

export default App;

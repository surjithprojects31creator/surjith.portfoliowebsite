/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        reactor: {
          bg: '#04070d',
          panel: '#0a1118',
          surface: '#0d1620',
          cyan: '#22d3ee',
          blue: '#3b82f6',
          glow: '#67e8f9',
          amber: '#f59e0b',
          red: '#ef4444',
          green: '#10b981',
          line: '#1e3a52',
          muted: '#5b7a93',
          text: '#cfe9f4',
        },
      },
      fontFamily: {
        display: ['"Orbitron"', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'monospace'],
        sans: ['"Rajdhani"', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
      animation: {
        'spin-slow': 'spin 24s linear infinite',
        'spin-slower': 'spin 40s linear infinite',
        'spin-reverse': 'spin-reverse 18s linear infinite',
        'spin-reverse-slow': 'spin-reverse 60s linear infinite',
        'pulse-core': 'pulse-core 3s ease-in-out infinite',
        'pulse-soft': 'pulse-soft 4s ease-in-out infinite',
        'flicker': 'flicker 6s linear infinite',
        'scan': 'scan 4s ease-in-out infinite',
        'float': 'float 8s ease-in-out infinite',
        'float-slow': 'float 14s ease-in-out infinite',
        'rise': 'rise 0.7s cubic-bezier(0.16,1,0.3,1) both',
        'sweep': 'sweep 3s ease-in-out infinite',
      },
      keyframes: {
        'spin-reverse': {
          '0%': { transform: 'rotate(360deg)' },
          '100%': { transform: 'rotate(0deg)' },
        },
        'pulse-core': {
          '0%, 100%': { opacity: '0.85', filter: 'brightness(1)' },
          '50%': { opacity: '1', filter: 'brightness(1.4)' },
        },
        'pulse-soft': {
          '0%, 100%': { opacity: '0.4' },
          '50%': { opacity: '0.9' },
        },
        'flicker': {
          '0%, 100%': { opacity: '1' },
          '3%': { opacity: '0.4' },
          '6%': { opacity: '1' },
          '78%': { opacity: '1' },
          '80%': { opacity: '0.6' },
          '82%': { opacity: '1' },
        },
        'scan': {
          '0%, 100%': { transform: 'translateY(-100%)', opacity: '0' },
          '50%': { transform: 'translateY(100%)', opacity: '0.8' },
        },
        'float': {
          '0%, 100%': { transform: 'translateY(0) translateX(0)' },
          '50%': { transform: 'translateY(-14px) translateX(6px)' },
        },
        'rise': {
          '0%': { opacity: '0', transform: 'translateY(28px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        'sweep': {
          '0%, 100%': { transform: 'translateX(-100%)' },
          '50%': { transform: 'translateX(100%)' },
        },
      },
    },
  },
  plugins: [],
};
